import numpy as np
from os import path
import sim
import time
import math
import random

import _thread as thread



import controlRobot as rob
import pygame

import time

import vrep
from PIL import Image as I
from vae import VAE
import torch
from torchvision import transforms, datasets
from torchvision import transforms


class Ballplate(object):
    def __init__(self):
        sim.simxFinish(-1)
        self.clientID = None

        self.ang2rad=1/180*3.1415926
        self.forward_ang = 0
        self.back_ang = 0
        self.left_ang = 0
        self.right_ang = 0
        self.max_sensor_distance = 20
        self.obsout =[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]



        self.step_size = 0.03 #0.02

        self.position = None

        self.target_position = None
        self.ball = None
        self.start_connection()  # 连接
        self.roboat = rob.Robot(self.clientID)





        self.object_init()
        self.get_position()
        # self.close()
        self.ball_init()

        self.first_dis1 = cau_dis2(self.target_position, self.position)

        self.lastdis = self.first_dis1

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.vae = VAE(image_channels=3).to(self.device)
        self.vae.load_state_dict(torch.load('vae.torch', map_location='cpu'))

        self.transform = transforms.Compose([
            transforms.Resize([64,64]),
            transforms.ToTensor(),
            ])

        self.final_z = self.ballvision_init()

    def start_connection(self):
        self.clientID = sim.simxStart('127.0.0.1', 19997, True, True, 5000, 5)  # start a connection
        if self.clientID != -1:
            print('Connected to remote API server')
        else:
            print('Failed connecting to remote API server')



    def ball_init(self):
        x_ori = 0.4198
        y_ori = 0.0944
        self.position[0] = x_ori + random.uniform(-0.425, 0.425)
        self.position[1] = y_ori + random.uniform(-0.425, 0.425)
        self.position[2] = 1.2467
        sim.simxSetObjectPosition(self.clientID, self.ball, -1, (self.position[0], self.position[1], self.position[2]), sim.simx_opmode_blocking)

    def plate_init(self):
        self.roboat.set_servo_position(6, 3.1415)
        self.roboat.set_servo_position(4, 0)


    def object_init(self):
        self.target_position = [0.4198, 0.0944, 1.2467] #center of board
        err_code, self.ball = sim.simxGetObjectHandle(self.clientID, 'Sphere', sim.simx_opmode_blocking)


    def ballvision_init(self):
        dataset = datasets.ImageFolder(root='./fixpic', transform=transforms.Compose([
            transforms.Resize([64, 64]),
            transforms.ToTensor(),
        ]))
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=True)
        fixed_x, _ = next(iter(dataloader))


        zout = self.vae.encode(fixed_x.cuda())

        zout = zout[0].cpu().detach().numpy()


        return zout[0]

    def vision(self):
        error, resolution, imageRGB = self.roboat.get_vision_image(self.roboat.vRGBs)
        # save left eye picture
        image_byte_array = np.array(imageRGB, dtype=np.uint8)
        image_buffer = I.frombuffer("RGB", (resolution[0], resolution[1]), image_byte_array, "raw", "RGB", 0, 1)
        img2 = np.asarray(image_buffer)
        save_img = image_buffer
        save_img = save_img.transpose(I.FLIP_TOP_BOTTOM)

        path = "./camera/pic/picture1.png"
        save_img.save(path)


        # save_img = np.array(save_img)
        # save_img = torch.from_numpy(save_img)

        dataset = datasets.ImageFolder(root='./camera', transform=transforms.Compose([
            transforms.Resize([64, 64]),
            transforms.ToTensor(),
        ]))
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=True)
        fixed_x, _ = next(iter(dataloader))


        zout = self.vae.encode(fixed_x.cuda())

        zout = zout[0].cpu().detach().numpy()

        self.obsout = zout[0]
        return zout[0]



    def step(self, action,steps):
        # 判断是否结束游戏，给出奖励
        u = np.argmax(action) + 1
        if (u == 1):
            self.go_forward()
        elif (u == 2):
            self.go_back()
        elif (u == 3):
            self.go_left()
        elif (u == 4):
            self.go_right()
        time.sleep(0.1)
        '''
        step1:Check reach destination
        '''
        self.get_position()
        img = self.vision()

        #print(self.final_z)



        dis = cau_dis2(self.position, self.target_position)

        cos = self.calcos(img)

        # if  dis<0.1 and steps>6 :  # 1% of the distance max  dist should be 0.636
        #     costs = cos
        #
        #     print('Success')
        #     return self._get_obs(), costs, True, {}

        '''
        step2:Check if almost fail
        '''
        if ((self.position)[2] < 1 ):
            costs = -1
            # print("Dangerous!!!")
            return self._get_obs(), costs, True, {}




        # if dis > 0.63:
        #     costs = -500
        #     # print("Dangerous!!!")
        #     return self._get_obs(), costs, True, {}

        # print(self.lastdis,dis)
        #costs = (math.pow((0.63 - dis), 2) - math.pow((0.63 - self.lastdis), 2)) * steps
        costs = cos

        #print(costs)
        #costs = dis * steps
        # (self.lastdis - dis) * 100
        self.lastdis = dis
        # print(action, costs)


        ################################
        #sum(np.multiply(a, b)) / (np.sqrt(sum(np.multiply(a, a))) * np.sqrt(sum(np.multiply(b, b))))
        ##################

        return self._get_obs(), costs, False, {}

    def calcos(self,a):
        return sum(np.multiply(a, self.final_z)) / (np.sqrt(sum(np.multiply(a, a))) * np.sqrt(sum(np.multiply(self.final_z, self.final_z))))

    def reset(self):
        self.stopflag = sim.simxStopSimulation(self.clientID, sim.simx_opmode_blocking)
        time.sleep(4)
        self.ball_init()
        time.sleep(1)

        self.startflag = sim.simxStartSimulation(self.clientID, sim.simx_opmode_blocking)
        # time.sleep(1)
        self.plate_init()
        time.sleep(0.5)

        self.object_init()
        self.get_position()

        self.first_dis1 = cau_dis2(self.target_position, self.position)
        self.lastdis = self.first_dis1
        print(f"  Initial Distance: {self.first_dis1}")

        return self._get_obs()



    def _get_obs(self):
        #return np.array([(self.target_position[0] - self.position[0]), (self.target_position[1] - self.position[1]), (self.target_position[2] - self.position[2])  ] )
        return np.array(self.obsout)
    def get_position(self):
        ret, self.position = sim.simxGetObjectPosition(self.clientID, self.ball, -1,
                                                       sim.simx_opmode_blocking)
        if ret != sim.simx_return_ok:
            print("Something is wrong!!!")
        self.forward_ang = self.roboat.get_servo_position(6)
        self.back_ang = self.roboat.get_servo_position(6)
        self.left_ang = self.roboat.get_servo_position(4)
        self.right_ang = self.roboat.get_servo_position(4)




    def go_forward(self):
        self.roboat.set_servo_position(6, (self.forward_ang + self.step_size))

    def go_back(self):
        self.roboat.set_servo_position(6, (self.back_ang - self.step_size))

    def go_left(self):
        self.roboat.set_servo_position(4, (self.left_ang + self.step_size))

    def go_right(self):
        self.roboat.set_servo_position(4, (self.right_ang - self.step_size))

    def close(self):
        sim.simxGetPingTime(self.clientID)
        self.stopflag = sim.simxStopSimulation(self.clientID, sim.simx_opmode_blocking)
        # sim.simxStopSimulation(self.clientID, sim.simx_opmode_oneshot)
        sim.simxFinish(self.clientID)


def cau_dis1(pos1, pos2):
    return math.sqrt(math.pow(pos1[0] - pos2[0], 2) + math.pow(pos1[1] - pos2[1], 2) + math.pow(pos1[2] - pos2[2], 2))


def cau_dis2(pos1, pos2):
    return abs(pos1[0] - pos2[0]) + abs(pos1[1] - pos2[1] + abs(pos1[2] - pos2[2]))