import _thread as thread

import numpy

import controlRobot as rob
import pygame
import sys
import time
import random
import os
import win32api
import vrep
from PIL import Image as I
import sim

# gym board range: X----> 0.4198 +- 0.425,   Y----> 0.0944 +- 0.425,  Z----> 1.2467


def PlaceBall():
    # Find coordincate for sphere
    ret, targetObj = sim.simxGetObjectHandle(clientID, 'Sphere', sim.simx_opmode_blocking)
    ret2, arr = sim.simxGetObjectPosition(clientID, targetObj, -1, sim.simx_opmode_blocking)

    if ret2 == sim.simx_return_ok:
        print(arr)

    # place the ball into random place on the plate
    x_ori = 0.4198
    y_ori = 0.0944
    arr[0] = x_ori + random.uniform(-0.425, 0.425)
    arr[1] = y_ori + random.uniform(-0.425, 0.425)
    arr[2] = 1.2467
    sim.simxSetObjectPosition(clientID, targetObj, -1, (arr[0], arr[1], arr[2]), sim.simx_opmode_blocking)
    return




def vinsion():
    while True:
        error, resolution, imageRGB = robot.get_vision_image(robot.vRGBs)
        # save left eye picture
        image_byte_array = numpy.array(imageRGB, dtype=numpy.uint8)
        image_buffer = I.frombuffer("RGB", (resolution[0], resolution[1]), image_byte_array, "raw", "RGB", 0, 1)
        img2 = numpy.asarray(image_buffer)
        save_img = image_buffer.transpose(I.ROTATE_180)  # 图片旋转180°

        i = time.time()

        path = "./camera/" + str(i) + ".png"
        save_img.save(path)
        print("Picture Saved")
        time.sleep(0.07)
    thread.exit_thread()
    return


if __name__ == "__main__":

    sim.simxFinish(-1) # just in case, close all opened connections
    clientID = sim.simxStart('127.0.0.1', 19997, True, True, 5000, 5)
    if clientID != -1:
        print('Connected to remote API server')
    else:
        print('Failed connecting to remote API server')
    end = sim.simxStopSimulation(clientID, sim.simx_opmode_blocking)
    time.sleep(2)  # time for reaction

    robot = rob.Robot(clientID)

    # start sim
    start = sim.simxStartSimulation(clientID, sim.simx_opmode_blocking)


    try:
        vinsion_thread = thread.start_new_thread(vinsion, ())
    except:
        print("Error: unable to start new thread")


    for i in range(25):
        PlaceBall()
        time.sleep(0.50)

    end = sim.simxStopSimulation(clientID, sim.simx_opmode_blocking)



